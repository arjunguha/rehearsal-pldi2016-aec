#!/bin/bash
repoquery -l $1