#!/bin/bash

for file in good/*; do
  puppet parser